//
//  SignUpViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 19/11/23.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var phoneNumberTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.passwordTF.isSecureTextEntry = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        usernameTF.text = ""
        phoneNumberTF.text = ""
        passwordTF.text = ""
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func siupButtonAction(_ sender: Any) {
       
        if self.usernameTF.text?.isEmpty == true || self.phoneNumberTF.text?.isEmpty == true || self.passwordTF.text?.isEmpty == true {
            AlertManager.showAlert(title: "Alert", message: "Please fill all fields", viewController: self)
        } else {
            SignUpAPI()
        }
    }
    
    func SignUpAPI() {
        
        let formData = [
            "username" : usernameTF.text ?? "",
            "phone_number" : phoneNumberTF.text ?? "",
            "password" : passwordTF.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: SignUpModel.self, apiUrl: ServiceAPI.signupURL, method: "POST", formData: formData as [String : Any]) { result in
            switch result {
            case .success(let response):
                print(response.status)
                print(response.message ?? "")
                DispatchQueue.main.async {
                   
//                        AlertManager.showAutoDismissAlert(title: "Success", message: "\(response.message ?? "")", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    AlertManager.showAlert(title: "", message: "\(response.message ?? "")", viewController: self)
                    
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
                
            }
        }
    }

}
