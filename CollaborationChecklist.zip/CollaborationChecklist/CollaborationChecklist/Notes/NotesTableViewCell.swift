//
//  NotesTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 04/10/23.
//

import UIKit

class NotesTableViewCell: UITableViewCell {

    @IBOutlet weak var editButton: UIButton!
    
    @IBOutlet weak var ContentLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
    @IBOutlet weak var NotesLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
