//
//  EditTopViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 06/10/23.
//

import UIKit

class EditTopViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        NotificationCenter.default.post(name: NSNotification.Name("CloseButtonTap"), object: nil)
    }
}
