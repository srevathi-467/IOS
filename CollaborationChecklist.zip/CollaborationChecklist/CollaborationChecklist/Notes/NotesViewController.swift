//
//  NotesViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 03/10/23.
//

import UIKit

class NotesViewController: UIViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var notesTableView: UITableView!
    @IBOutlet weak var titleButton: UIButton!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var editBottomView: UIView!
    
    var indexPath: IndexPath?
    var notes : Notes!
    var filtered: [notes]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    var sender : [String:Any] = [String:Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
//        UserDefaults.standard.removeObject(forKey: "Reminder")
        
        NotificationCenter.default.addObserver(self, selector: #selector(editButtonTapAction), name: NSNotification.Name("EditButtonTap"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(closeButtonTapAction), name: NSNotification.Name("CloseButtonTap"), object: nil)
        //        NotificationCenter.default.addObserver(self, selector: #selector(notebookCloseTapAction), name: NSNotification.Name("NotebookCloseTap"), object: nil)
        
        self.notesTableView.delegate = self
        self.notesTableView.dataSource = self
//        self.notesTableView.rowHeight = UITableView.automaticDimension
//        self.notesTableView.estimatedRowHeight = 90.0
        
        searchBar.isHidden = true
        searchBar.delegate = self
        
        //        editView.isHidden = true
        editBottomView.isHidden = true
        
    }
    
    @objc func editButtonTapAction() {
        //        editView.isHidden = false
        editBottomView.isHidden = false
        tabBarController?.tabBar.isHidden = true
        countLabel.isHidden = true
    }
    
    @objc func closeButtonTapAction() {
        //        editView.isHidden = true
        editBottomView.isHidden =  true
        tabBarController?.tabBar.isHidden = false
        countLabel.isHidden = false
    }
    
    @objc func notebookCloseTapAction() {
        
        //        tabBarController?.tabBar.isHidden = false
    }
    
    @IBAction func logoutButtonAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        AlertManager.showDestructiveAlert(title: "Logout", message: "Are you sure you want to logout?", viewController: self, okButtonTitle: "LOGOUT", cancelButtonTitle: "Cancel", okHandler:  {
            self.logOutAPI()
        })
    }
    
    @IBAction func searchButtonAction(_ sender: Any) {
        searchBar.isHidden = false
    }
    
    @IBAction func titleButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "NoteBooksViewController") as! NoteBooksViewController
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        //        tabBarController?.tabBar.isHidden = true
    }
    
    @IBAction func createButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "CreateNotesViewController") as! CreateNotesViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        NotesAPI()
    }
    
    func NotesAPI() {
        APIHandler.shared.getAPIValues(type: Notes.self, apiUrl: "\(ServiceAPI.NotesURL)UserId=\(savedUserId ?? 0)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.notes = data
                print(self.notes.data ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.notes.data?.count ?? 0) Notes"
                    self.notesTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
    func logOutAPI() {
        APIHandler.shared.getAPIValues(type: BoolModel.self, apiUrl: "\(ServiceAPI.LogoutURL)UserId=\(savedUserId ?? 0)", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                    UserDefaultsManager.shared.removeUserData()
                    self.reset()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func reset() {
        UserDefaults.standard.removeObject(forKey: "Reminder")
        UserDefaults.standard.removeObject(forKey: "Add")
        UserDefaults.standard.removeObject(forKey: "CollabIds")
    }
}

extension NotesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.notes?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotesTableViewCell", for: indexPath) as! NotesTableViewCell
        
        cell.editButton.tag = indexPath.row
        cell.editButton.addTarget(self, action: #selector(DeleteNotesAPI), for: .touchUpInside)
        
        if let detail = searching ? self.filtered[indexPath.row] : self.notes?.data?[indexPath.row] {
            cell.ContentLabel.text = "\(detail.content ?? "")"
            cell.NotesLabel.text = "\(detail.heading ?? "")"
            cell.DateLabel.text = "\(detail.eventDatetime ?? "")"
            cell.editButton.isHidden = false
        } else {
            cell.ContentLabel.text = "No Notes Added"
            cell.NotesLabel.text = ""
            cell.DateLabel.text = ""
            cell.editButton.isHidden = true
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "CreateNotesViewController") as! CreateNotesViewController
        
        self.sender = ["Heading":self.notes.data?[indexPath.row].heading ?? "", "Content":self.notes.data?[indexPath.row].content ?? "", "Notebook":self.notes.data?[indexPath.row].notebookID ?? ""]
        
        vc.receiver = self.sender
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
    @objc func DeleteNotesAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let NotebookID = self.notes.data?[rowToRemove].notebookID else {
            return
        }
        
        if let removeIndex = self.notes.data?.firstIndex(where: {$0.notebookID == NotebookID}) {
            
            self.notes.data?.remove(at: removeIndex)
            self.NotesAPI()
        }
        
        self.notesTableView.reloadData()
        
        let formData = ["notebook_id" : NotebookID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteNotesURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.NotesAPI()
                    self.notesTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}

extension NotesViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = notes.data?.filter { note in
                return (note.heading?.range(of: searchText, options: .caseInsensitive) != nil) ||
                       (note.content?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        notesTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
//        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
//        searchBar.resignFirstResponder()
        notesTableView.reloadData()
    }
}

