//
//  CreateNotesViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 10/10/23.
//

import UIKit

class CreateNotesViewController: UIViewController {
    
    @IBOutlet weak var Heading: UITextField!
    @IBOutlet weak var ContentButton: UITextView!
    @IBOutlet weak var dateAndTimeLabel: UILabel!
    
    var receiver : [String:Any] = [String:Any]()
    
    var notebookId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.Heading.text = "\(self.receiver["Heading"] ?? "")"
        self.ContentButton.text = "\(self.receiver["Content"] ?? "")"
        self.notebookId = "\(self.receiver["Notebook"] ?? "")"
        
        updateDateTimeLabel()
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        AddNotesAPI()
    }
    
    func updateDateTimeLabel() {
        // Get the current date and time
        let currentDate = Date()
        
        // Create a date formatter to format the date and time
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss" // You can customize the format
        
        // Format the date and time as a string
        let formattedDateTime = dateFormatter.string(from: currentDate)
        
        // Update the label with the formatted date and time
        dateAndTimeLabel.text = formattedDateTime
    }
    
    func AddNotesAPI() {
        guard let User_id = UserDefaultsManager.shared.getUserName() else {
            return
        }
        let formData: [String: String] = [
            "notebook_id": "\(notebookId)",
            "UserId": "\(User_id)",
            "heading": Heading.text ?? "",
            "content": ContentButton.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: AddNotes.self, apiUrl: ServiceAPI.AddNotesURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    print(formData)
                    AlertManager.showAutoDismissAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    
}
