//
//  NotebooksCollectionViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 06/10/23.
//

import UIKit

class NotebooksCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var coverImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    
}
