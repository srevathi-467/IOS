
import Foundation

// MARK: - Welcome
struct AddNotes: Codable {
    var status, message: String?
}
