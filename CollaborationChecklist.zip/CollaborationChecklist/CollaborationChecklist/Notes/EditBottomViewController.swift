//
//  EditBottomViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 07/10/23.
//

import UIKit

class EditBottomViewController: UIViewController {
    
    @IBOutlet weak var moveView: UIView!
    @IBOutlet weak var hideView: UIView!
    @IBOutlet weak var pinView: UIView!
    @IBOutlet weak var deleteView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        hideView.addAction(for: .tap) {
            let alert = UIAlertController(title: "Hidden notes", message: "To protect your privacy, hidden notes won't be synced to the cloud.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.destructive, handler: { action in
                let alert = UIAlertController(title: "Note hidden", message: "You can see this note in 'Hidden notes'.", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel))
                self.present(alert, animated: true)
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel))
            self.present(alert, animated: true)
        }
        
        deleteView.addAction(for: .tap) {
            let alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertController.Style.actionSheet)
            alert.addAction(UIAlertAction(title: "Delete 1 items", style: UIAlertAction.Style.default))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel))
            self.present(alert, animated: true)
        }
    }
    
}
