//
//  NoteBooksViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 06/10/23.
//

import UIKit

class NoteBooksViewController: UIViewController {
    
    @IBOutlet weak var notebookCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.notebookCollectionView.delegate = self
        self.notebookCollectionView.dataSource = self
        self.notebookCollectionView.backgroundColor = .tertiarySystemGroupedBackground
        
        let direction = UICollectionViewFlowLayout()
        direction.scrollDirection = .vertical
        direction.itemSize = CGSize(width: 110.0, height: 200.0)
        self.notebookCollectionView.collectionViewLayout = direction
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss(animated: true)
//        NotificationCenter.default.post(name: NSNotification.Name("NotebookCloseTap"), object: nil)
    }
}

extension NoteBooksViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NotebooksCollectionViewCell", for: indexPath) as! NotebooksCollectionViewCell
        
        if indexPath.row == 0 {
            cell.coverImage.backgroundColor = .opaqueSeparator.withAlphaComponent(0.2)
            cell.coverImage.layer.cornerRadius = 15
            cell.coverImage.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner]
            cell.titleLabel.text = "New"
            cell.countLabel.text = "notebook"
            cell.countLabel.textColor = .black
        }
        
        if indexPath.row == 1 {
            cell.coverImage.backgroundColor = .blue
            cell.coverImage.layer.cornerRadius = 15
            cell.coverImage.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner]
            cell.titleLabel.text = "All notes"
            cell.countLabel.text = "6"
            cell.countLabel.textColor = .lightGray
        }
        
        return cell
    }
}
