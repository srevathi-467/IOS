import Foundation

// MARK: - CollabIDSModel
struct Contacts: Codable {
    var data: [contacts]?
}

// MARK: - Datum
struct contacts: Codable {
    var userID, username, phonenumber: String?

    enum CodingKeys: String, CodingKey {
        case userID = "UserId"
        case username, phonenumber
    }
}
