//
//  MembersModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 02/12/23.
//

import Foundation

// MARK: - MembersModel
struct MembersModel: Codable {
    var status: String?
    var userDetails: [UserDetail]?

    enum CodingKeys: String, CodingKey {
        case status
        case userDetails = "user_details"
    }
}

// MARK: - UserDetail
struct UserDetail: Codable {
    var requestedID: Int?
    var username: String?
    var userID: Int?

    enum CodingKeys: String, CodingKey {
        case requestedID = "requested_id"
        case username
        case userID = "UserId"
    }
}
