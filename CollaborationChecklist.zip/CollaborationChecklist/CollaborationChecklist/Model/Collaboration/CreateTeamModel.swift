//
//  CreateTeamModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 21/11/23.
//

import Foundation

// MARK: - CreateTeamModel
struct CreateTeamModel: Codable {
    var status, message: String?
}
