//
//  LocalDataModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 19/11/23.
//

import Foundation

struct LocalDataModel: Codable {
    var data: [LocalData]?
}

// MARK: - Datum
struct LocalData: Codable {
    var id, name: String?
}

