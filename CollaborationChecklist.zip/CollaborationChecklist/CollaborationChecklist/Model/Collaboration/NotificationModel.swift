//
//  NotificationModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 27/11/23.
//

import Foundation

// MARK: - NotificationModel
struct NotificationModel: Codable {
    var status, message: String?
    var data: [Notify]?
}

// MARK: - Datum
struct Notify: Codable {
    var userID, collabID, groupName, requestUsername: String?
    var signupUsername: String?

    enum CodingKeys: String, CodingKey {
        case userID = "UserId"
        case collabID = "Collab_Id"
        case groupName = "group_name"
        case requestUsername = "request_username"
        case signupUsername = "signup_username"
    }
}
