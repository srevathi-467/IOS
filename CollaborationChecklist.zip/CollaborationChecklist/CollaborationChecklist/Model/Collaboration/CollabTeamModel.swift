//
//  CollabTeamModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 22/11/23.
//

import Foundation

// MARK: - CollabTeamModel
// MARK: - CollabTeamModel
struct CollabTeamModel: Codable {
    var status: String?
    var details: [Detail]?
}

// MARK: - Detail
struct Detail: Codable {
    var collabID: Int?
    var groupName: String?
    var members: [Member]?

    enum CodingKeys: String, CodingKey {
        case collabID = "Collab_Id"
        case groupName = "group_name"
        case members
    }
}

// MARK: - Member
struct Member: Codable {
    var requestedid: Int?
    var username: String?
}
