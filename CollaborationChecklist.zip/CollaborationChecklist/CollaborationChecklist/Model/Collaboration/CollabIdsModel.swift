//
//  CollabIdsModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 30/11/23.
//

import Foundation

// MARK: - CollabIDSModel
struct CollabIDSModel: Codable {
    var userID: Int?
    var details: [Details]?

    enum CodingKeys: String, CodingKey {
        case userID = "UserId"
        case details
    }
}

// MARK: - Detail
struct Details: Codable {
    var collabID, groupName: String?

    enum CodingKeys: String, CodingKey {
        case collabID = "Collab_Id"
        case groupName = "group_name"
    }
}

