//
//  TaskDetailsModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 25/11/23.
//

import Foundation

//// MARK: - TaskDetailsModel
//struct TaskDetailsModel: Codable {
//    var status: Bool?
//    var message: String?
//    var tasks: [Task]?
//}
//
//// MARK: - Task
//struct Task: Codable {
//    var taskID, taskIssued, date, username: String?
//    var groupName: String?
//
//    enum CodingKeys: String, CodingKey {
//        case taskID = "task_Id"
//        case taskIssued = "task_issued"
//        case date, username
//        case groupName = "group_name"
//    }
//}

//// MARK: - NotificationModel
//struct TaskDetailsModel: Codable {
//    var status: String?
//    var tasks: [Tasks]?
//}
//
//// MARK: - Task
//struct Tasks: Codable {
//    var collabID: Int?
//    var groupName, taskIssued, date, assignedUsername: String?
//
//    enum CodingKeys: String, CodingKey {
//        case collabID = "Collab_Id"
//        case groupName = "group_name"
//        case taskIssued = "task_issued"
//        case date
//        case assignedUsername = "assigned_username"
//    }
//}

// MARK: - LoginModel
struct TaskDetailsModel: Codable {
    var status: String?
    var tasks: [Tasks]?
}

// MARK: - Task
struct Tasks: Codable {
    var collabID: Int?
    var groupName: String?
    var taskID: Int?
    var taskIssued, date, assignedUsername: String?

    enum CodingKeys: String, CodingKey {
        case collabID = "collab_id"
        case groupName = "group_name"
        case taskID = "task_Id"
        case taskIssued = "task_issued"
        case date
        case assignedUsername = "assigned_username"
    }
}

