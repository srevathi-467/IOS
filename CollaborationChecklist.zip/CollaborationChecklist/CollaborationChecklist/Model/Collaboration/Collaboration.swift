
import Foundation

// MARK: - Welcome
struct Collaboration: Codable {
    var data: [collaboration]?
}

// MARK: - Datum
struct collaboration: Codable {
    var name: String?
}
