
import Foundation

// MARK: - Welcome
struct Login: Codable {
    var status: Bool?
    var message: String?
    var data: [login]?
}

// MARK: - Datum
struct login: Codable {
    var UserId: Int?
    var username, phoneNumber, password: String?

    enum CodingKeys: String, CodingKey {
        case UserId, username
        case phoneNumber = "phone_number"
        case password
    }
}
