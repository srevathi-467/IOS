//
//  SignUpModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 26/11/23.
//

import Foundation

struct SignUpModel: Codable {
    var status: Bool?
    var message: String?
}
