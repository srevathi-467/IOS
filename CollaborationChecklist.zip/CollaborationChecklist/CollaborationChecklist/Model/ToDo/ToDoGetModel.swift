//

import Foundation

// MARK: - NotificationModel
struct ToDoGet: Codable {
    var data: [todo]?
}

// MARK: - Datum
struct todo: Codable {
    var userID, content, reminder, todoID: String?
    var status: String?

    enum CodingKeys: String, CodingKey {
        case userID = "UserId"
        case content, reminder
        case todoID = "todo_id"
        case status
    }
}
