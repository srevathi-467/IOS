//
//  PostStringModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 27/11/23.
//

import Foundation

struct PostStringModel: Codable {
    var status, message: String?
}
