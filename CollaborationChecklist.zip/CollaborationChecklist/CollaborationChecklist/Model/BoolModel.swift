//
//  BoolModel.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 09/12/23.
//

import Foundation

struct BoolModel: Codable {
    var status: Bool?
    var message: String?
}
