import Foundation

// MARK: - Welcome
struct CompleteYesButton: Codable {
    var status, message: String?
}

