import Foundation

// MARK: - Welcome
struct Activetask: Codable {
    var data: [activetask]?
}

// MARK: - Datum
struct activetask: Codable {
    var notebookID, userID, notebook, heading: String?
    var content, date, status: String?

    enum CodingKeys: String, CodingKey {
        case notebookID = "notebook_id"
        case userID = "User_id"
        case notebook, heading, content, date, status
    }
}
