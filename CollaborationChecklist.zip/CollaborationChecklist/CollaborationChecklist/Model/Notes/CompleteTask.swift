import Foundation

// MARK: - Welcome
struct CompleteTask: Codable {
    var data: [completetask]?
}

// MARK: - Datum
struct completetask: Codable {
    var notebookID, userID, notebook, heading: String?
    var content, date, status, username: String?

    enum CodingKeys: String, CodingKey {
        case notebookID = "notebook_id"
        case userID = "User_id"
        case notebook, heading, content, date, status, username
    }
}
