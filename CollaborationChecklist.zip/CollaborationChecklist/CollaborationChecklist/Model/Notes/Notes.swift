import Foundation

//// MARK: - Welcome
//struct Notes: Codable {
//    var data: [notes]?
//}
//
//// MARK: - Datum
//struct notes: Codable {
//    var notebookID, userID, notebook, heading: String?
//    var content, eventDatetime: String?
//
//    enum CodingKeys: String, CodingKey {
//        case notebookID = "notebook_id"
//        case userID = "UserId"
//        case notebook, heading, content
//        case eventDatetime = "event_datetime"
//    }
//}

// MARK: - NotificationModel
struct Notes: Codable {
    var data: [notes]?
}

// MARK: - Datum
struct notes: Codable {
    var notebookID, userID, notebook, heading: String?
    var content, eventDatetime: String?
    
    enum CodingKeys: String, CodingKey {
        case notebookID = "notebook_id"
        case userID = "UserId"
        case notebook, heading, content
        case eventDatetime = "event_datetime"
    }
}
