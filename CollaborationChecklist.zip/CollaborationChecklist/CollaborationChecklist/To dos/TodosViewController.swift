//
//  TodosViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 03/10/23.
//

import UIKit

class TodosViewController: UIViewController, TodoViewControllerDelegate {
    
    @IBOutlet weak var todosTableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var todo:ToDoGet!
    var filtered: [todo]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.todosTableView.delegate = self
        self.todosTableView.dataSource = self
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    @IBAction func createButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "CreateViewController") as! CreateViewController
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        viewController.delegate = self
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }
    
    func didDismissViewController() {
//        self.todosTableView.reloadData()
        self.ToDoGetAPI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.todosTableView.reloadData()
        }
        ToDoGetAPI()
    }
    
    func ToDoGetAPI() {
        APIHandler.shared.getAPIValues(type: ToDoGet.self, apiUrl: "\(ServiceAPI.todogetURL)&UserId=\(savedUserId ?? 0)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.todo = data
                print(self.todo.data ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.todo.data?.count ?? 0) To-Dos"
                    self.todosTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension TodosViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            // Return the count of "undone" tasks
            if searching {
                return self.filtered.filter { $0.status == "undone"}.count
            } else {
                return self.todo?.data?.filter { $0.status == "undone" }.count ?? 0
            }
        } else if section == 1 {
            // Return the count of "done" tasks
            if searching {
                return self.filtered.filter { $0.status == "done"}.count
            } else {
                return self.todo?.data?.filter { $0.status == "done" }.count ?? 0
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodosTableViewCell", for: indexPath) as! TodosTableViewCell
        
//        cell.doneButton.tag = indexPath.row
//        cell.doneButton.addTarget(self, action: #selector(doneUndoneAction), for: .touchUpInside)
        
//        cell.deleteButton.tag = indexPath.row
//        cell.deleteButton.addTarget(self, action: #selector(DeleteTodoAPI), for: .touchUpInside)
        
        if indexPath.section == 0 {
            // Configure cell for "undone" tasks
            if let undoneTask = searching ? self.filtered[indexPath.row] : self.todo?.data?.filter({ $0.status == "undone" })[indexPath.row] {
                cell.ListLabel.text = undoneTask.content
                cell.reminderLabel.text = undoneTask.reminder
                
                if undoneTask.reminder == "0000-00-00 00:00:00" {
                    cell.reminderLabel.isHidden = true
                } else {
                    cell.reminderLabel.isHidden = false
                }
            }
            cell.deleteButton.tag = indexPath.row
            cell.deleteButton.addTarget(self, action: #selector(DeleteTodoAPI), for: .touchUpInside)
            
            // Set default image for undoneButton
            cell.doneButton.tag = indexPath.row
            cell.doneButton.addTarget(self, action: #selector(doneUndoneAction), for: .touchUpInside)
            cell.doneButton.tag = indexPath.section * 1000 + indexPath.row // Use a formula to combine section and row
            cell.doneButton.setImage(UIImage(systemName: "circle"), for: .normal)
            cell.doneButton.tintColor = .white
        } else if indexPath.section == 1 {
            // Configure cell for "done" tasks
            if let doneTask = searching ? self.filtered[indexPath.row] : self.todo?.data?.filter({ $0.status == "done" })[indexPath.row] {
                cell.ListLabel.text = doneTask.content
                cell.reminderLabel.text = doneTask.reminder
                
                if doneTask.reminder == "0000-00-00 00:00:00" {
                    cell.reminderLabel.isHidden = true
                } else {
                    cell.reminderLabel.isHidden = false
                }
            }
            cell.deleteButton.tag = indexPath.row
            cell.deleteButton.addTarget(self, action: #selector(DeleteTodoAPI), for: .touchUpInside)
            
            // Set image for doneButton for "done" tasks
            cell.doneButton.tag = indexPath.section * 1000 + indexPath.row
            cell.doneButton.addTarget(self, action: #selector(doneUndoneAction), for: .touchUpInside)
            cell.doneButton.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
            cell.doneButton.tintColor = UIColor(red: 109/255.0, green: 199/255.0, blue: 197/255.0, alpha: 1)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 1 {
            return "Done"
        }
        return ""
    }
    
    @objc func doneUndoneAction(sender: UIButton) {
        let section = sender.tag / 1000
            let row = sender.tag % 1000

            var todoArray: [todo]?

            if section == 0 {
                todoArray = self.todo?.data?.filter({ $0.status == "undone" })
            } else if section == 1 {
                todoArray = self.todo?.data?.filter({ $0.status == "done" })
            }

            guard let selectedArray = todoArray, row >= 0, row < selectedArray.count else {
                return
            }

            guard let TodoID = selectedArray[row].todoID else {
                return
            }

        
        let formData = ["todo_id" : TodoID]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.UpdateTodoURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.ToDoGetAPI()
                    self.todosTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    @objc func DeleteTodoAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let TodoID = self.todo.data?[rowToRemove].todoID else {
            return
        }
        
        if let removeIndex = self.todo.data?.firstIndex(where: {$0.todoID == TodoID}) {
            
            self.todo.data?.remove(at: removeIndex)
        }
        
        self.todosTableView.reloadData()
        
        let formData = ["todo_id" : TodoID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteTodoURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.ToDoGetAPI()
                    self.todosTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
}

extension TodosViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = todo.data?.filter { note in
                let contentMatch = (note.content?.range(of: searchText, options: .caseInsensitive) != nil)
                return contentMatch && (note.status == "undone" || note.status == "done")
            }

            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        todosTableView.reloadData()
    }

    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
//        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
//        searchBar.resignFirstResponder()
        todosTableView.reloadData()
    }
}


