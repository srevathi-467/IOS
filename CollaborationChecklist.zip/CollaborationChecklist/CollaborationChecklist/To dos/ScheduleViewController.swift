//
//  ScheduleViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 11/10/23.
//

import UIKit

class ScheduleViewController: UIViewController {
    
    @IBOutlet weak var reminderPicker: UIDatePicker!
    
    var didSelectDate: ((String) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        let selectedDate = reminderPicker.date
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                let dateString = dateFormatter.string(from: selectedDate)
                
                // Pass the selected date back to the CreateViewController
                didSelectDate?(dateString)
                
                dismiss(animated: true)
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
}
