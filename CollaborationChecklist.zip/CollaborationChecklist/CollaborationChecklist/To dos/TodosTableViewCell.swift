//
//  TodosTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 04/10/23.
//

import UIKit

class TodosTableViewCell: UITableViewCell {
    
    @IBOutlet weak var ListLabel: UILabel!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var reminderLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
