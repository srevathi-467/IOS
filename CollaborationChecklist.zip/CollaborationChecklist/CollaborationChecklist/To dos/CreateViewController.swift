//
//  CreateViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 11/10/23.
//

import UIKit

protocol TodoViewControllerDelegate: AnyObject {
    func didDismissViewController()
}

class CreateViewController: UIViewController {
    
    @IBOutlet weak var todoTextfield: UITextField!
    @IBOutlet weak var reminderLabel: UILabel!
    
    weak var delegate: TodoViewControllerDelegate?
    
    var selectedDate = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
            let reminder = UserDefaults.standard.value(forKey: "Reminder") as? String
            self.reminderLabel.text = reminder
        }
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        
        let userId = UserDefaultsManager.shared.getUserName() ?? 0
        
        let status = "undone"
        
        let formData = [
            "content" : self.todoTextfield.text ?? "",
            "UserId" : userId,
            "status" : status,
            "reminder" : self.reminderLabel.text ?? ""
        ] as [String : Any]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.AddTodoListURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.dismiss(animated: true) {
                        UserDefaults.standard.removeObject(forKey: "Reminder")
                        self.delegate?.didDismissViewController()
                    }
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss(animated: true) {
            UserDefaults.standard.removeObject(forKey: "Reminder")
        }
    }
    
    @IBAction func reminderButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ScheduleViewController") as! ScheduleViewController
            vc.modalPresentationStyle = .overCurrentContext
            
            // Set up a closure to handle the selected date
            vc.didSelectDate = { [weak self] date in
                self?.updateReminderLabel(date)
            }
            
            present(vc, animated: true)
    }
    
    // Function to update the reminderLabel and UserDefaults
    private func updateReminderLabel(_ date: String) {
        DispatchQueue.main.async {
            self.reminderLabel.text = date
            UserDefaults.standard.setValue(date, forKey: "Reminder")
        }
    }
    
}
