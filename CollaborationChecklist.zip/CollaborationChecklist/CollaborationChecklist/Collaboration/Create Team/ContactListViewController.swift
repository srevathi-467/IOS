//
//  ContactListViewController.swift
//  CollaborationChecklist
//
//  Created by SAIL01 on 02/11/23.
//

import UIKit

class ContactListViewController: UIViewController {
    
    @IBOutlet weak var contactsTableView: UITableView!
    var contacts : Contacts!
    
    var selectedContacts : LocalDataModel!
    var CollabID = Int()
    var savedUserId = UserDefaultsManager.shared.getUserName()
    var groupName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.contactsTableView.delegate = self
        self.contactsTableView.dataSource = self
        self.contactsTableView.allowsMultipleSelection = true
    }
    override func viewWillAppear(_ animated: Bool) {
        ContactsAPI()
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        if let selectedData = selectedContacts {
            // Access selectedData.data to get the array of selected contacts
            // Do something with the selected data
            print(selectedData.data ?? [])
        }
        
        if let addValue = UserDefaults.standard.value(forKey: "Add") as? String, addValue == "Add" {
            
            guard let requestedIds = self.selectedContacts.data?.map({ "\($0.id ?? "")" })// Convert ids to strings
            else {
                print("Error: Invalid data for API request")
                return
            }
            
            let requestedIdsString = requestedIds.joined(separator: ",")
            
            let formData = [
                "Collab_Id": self.CollabID,
                "UserId": self.savedUserId ?? 0,
                "requestedId": requestedIdsString,
                "group_name": self.groupName
            ] as [String : Any]
            
            
            APIHandler().postAPIValues(type: CreateTeamModel.self, apiUrl: ServiceAPI.AddMembersURL, method: "POST", formData: formData) { result in
                switch result{
                case .success(let response):
                    print(response.status ?? "")
                    print(response.message ?? "")
                    DispatchQueue.main.async {
                        DataManager.shared.selectedContacts.data?.removeAll()
                        UserDefaults.standard.removeObject(forKey: "Add")
                    }
                case .failure(let error):
                    print(error)
                    print(error.localizedDescription)
                }
            }
        }
        
        // Dismiss the view controller
        dismiss(animated: true) {
            // Additional actions after dismissal
            
            
        }
    }
    
    func ContactsAPI() {
        APIHandler.shared.getAPIValues(type: Contacts.self, apiUrl: ServiceAPI.ContactsURL , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.contacts = data
                print(self.contacts.data ?? "")
                DispatchQueue.main.async {
                    self.contactsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension ContactListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.contacts?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactListTableViewCell", for: indexPath) as! ContactListTableViewCell
        if let detail = self.contacts?.data?[indexPath.row] {
            cell.NameButton.text = "\(detail.username ?? "")"
            
        } else {
            cell.NameButton.text = "No Contacts"
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? ContactListTableViewCell {
            cell.cellView.backgroundColor = UIColor(red: 109/255.0, green: 199/255.0, blue: 197/255.0, alpha: 1)
            
            // Ensure selectedContacts is not nil
            if selectedContacts == nil {
                selectedContacts = LocalDataModel(data: [])
            }
            
            // Ensure selectedContacts.data is not nil
            if selectedContacts.data == nil {
                selectedContacts.data = []
            }
            
            if let selectedContact = self.contacts?.data?[indexPath.row] {
                // Check if the contact is already in the selectedContacts.data
                if let existingIndex = selectedContacts.data?.firstIndex(where: { $0.id == selectedContact.userID }) {
                    // Update existing contact data
                    selectedContacts.data?[existingIndex].name = selectedContact.username
                    
                    // Pass the single LocalData object to the function
                    if let updatedContact = selectedContacts.data?[existingIndex] {
                        DataManager.shared.updateOrAddSelectedContact(updatedContact)
                    }
                    print("Contact already exists.")
                } else {
                    // Add a new contact to selectedContacts.data
                    var newElement = LocalData()
                    newElement.name = selectedContact.username
                    newElement.id = selectedContact.userID
                    selectedContacts.data?.append(newElement)
                    
                    // Pass the single LocalData object to the function
                    DataManager.shared.updateOrAddSelectedContact(newElement)
                }
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? ContactListTableViewCell {
            cell.cellView.backgroundColor = .clear
        }
    }
}

class DataManager {
    static let shared = DataManager()
    
    private init() {}
    
    var selectedContacts: LocalDataModel = LocalDataModel(data: [])
    
    func updateOrAddSelectedContact(_ contact: LocalData) {
        if let existingIndex = selectedContacts.data?.firstIndex(where: { $0.id == contact.id }) {
            // Update existing contact data
            selectedContacts.data?[existingIndex] = contact
        } else {
            // Add a new contact to selectedContacts.data
            selectedContacts.data?.append(contact)
        }
    }
}


