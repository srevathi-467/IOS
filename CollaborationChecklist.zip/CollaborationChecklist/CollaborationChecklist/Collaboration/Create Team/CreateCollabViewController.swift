//
//  CreateCollabViewController.swift
//  CollaborationChecklist
//
//  Created by SAIL01 on 02/11/23.
//

import UIKit

protocol CollabViewControllerDelegate: AnyObject {
    func didDismissViewController()
}

class CreateCollabViewController: UIViewController {
    
    @IBOutlet weak var collaborationTableView: UITableView!
    @IBOutlet weak var CollaborationIDLabel: UILabel!
    @IBOutlet weak var teamNameTextField: UITextField!
    
    weak var delegate: TodoViewControllerDelegate?
    
    var members : LocalDataModel!
    var createTeam : CreateTeamModel!
    let userId = UserDefaultsManager.shared.getUserName()
//    var selectedContacts: LocalDataModel?
    
    
    var ID = ""
    let characters = "1234567890"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        self.members = SelectedLabel(label: selectedContacts?.label ?? [])
//        print(self.members ?? "")
        
        self.collaborationTableView.delegate = self
        self.collaborationTableView.dataSource = self
        
        for _ in 1...6 {
            if let randomString = characters.randomElement() {
                ID.append(randomString)
            }
        }
        self.CollaborationIDLabel.text = "Collaboration ID : \(ID)"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.members = DataManager.shared.selectedContacts
        DispatchQueue.main.async {
            self.collaborationTableView.reloadData()
        }
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        DataManager.shared.selectedContacts.data?.removeAll()
//        dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func createButtonAction(_ sender: Any) {
        CollabRequestAPI()
//        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ContactListViewController") as! ContactListViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true, completion: nil)
    }
    
    func CollabRequestAPI() {
        
        let userIdString = self.userId
            let teamUserId = Int(userIdString ?? 0)
        
        guard let requestedIds = self.members.data?.map({ "\($0.id ?? "")" }), // Convert ids to strings
                  let teamName = self.teamNameTextField.text else {
                print("Error: Invalid data for API request")
                return
            }

            // Join requestedIds array into a comma-separated string
            let requestedIdsString = requestedIds.joined(separator: ",")

            let formData = [
                "Collab_Id": self.ID,
                "UserId": teamUserId,
                "requestedId": requestedIdsString,
                "group_name": teamName
            ] as [String : Any]


        APIHandler().postAPIValues(type: CreateTeamModel.self, apiUrl: ServiceAPI.CreateTeamURL, method: "POST", formData: formData) { result in
            switch result{
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    DataManager.shared.selectedContacts.data?.removeAll()
                    AlertManager.showAutoDismissAlert(title: "Success", message: "Group created successfully!", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
}

extension CreateCollabViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.members?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CreateCollabTableViewCell", for: indexPath) as! CreateCollabTableViewCell
        
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(DeleteAction), for: .touchUpInside)

        if let memberNames = self.members?.data?[indexPath.row] {
            cell.membersNameLabel.text = "\(memberNames.name ?? "")"
            DispatchQueue.main.async {
                self.collaborationTableView.reloadData()
            }
            
            } else {
                cell.membersNameLabel.text = "No members"
            }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    @objc func DeleteAction(sender: UIButton) {
        let removeRow = sender.tag
        
        guard let removeId = self.members.data?[removeRow].id else {
            return
        }
        if let removeIndex = self.members.data?.firstIndex(where: {$0.id == removeId}) {
            self.members.data?.remove(at: removeIndex)
            DataManager.shared.selectedContacts.data?.remove(at: removeIndex)
            self.collaborationTableView.reloadData()
        }
    }
    
}
