//
//  ContactListTableViewCell.swift
//  CollaborationChecklist
//
//  Created by SAIL01 on 03/11/23.
//

import UIKit

class ContactListTableViewCell: UITableViewCell {

    @IBOutlet weak var NameButton: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
