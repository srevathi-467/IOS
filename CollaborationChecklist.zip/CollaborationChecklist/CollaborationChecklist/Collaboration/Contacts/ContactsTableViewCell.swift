//
//  ContactsTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 27/10/23.
//

import UIKit

class ContactsTableViewCell: UITableViewCell {

    @IBOutlet weak var ContactLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
