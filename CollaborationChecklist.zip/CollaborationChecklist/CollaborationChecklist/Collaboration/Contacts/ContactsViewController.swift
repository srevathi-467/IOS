//
//  ContactsViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 27/10/23.
//

import UIKit

class ContactsViewController: UIViewController {
    
    @IBOutlet weak var contactsTableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var contacts : Contacts!
    var filtered: [contacts]!
    var searching : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.contactsTableView.delegate = self
        self.contactsTableView.dataSource = self
        
        searchBar.isHidden = true
        searchBar.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        ContactsAPI()
    }
    
    @IBAction func searchAction(_ sender: Any) {
        searchBar.isHidden = false
    }
    
    
    func ContactsAPI() {
        APIHandler.shared.getAPIValues(type: Contacts.self, apiUrl: ServiceAPI.ContactsURL , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.contacts = data
                print(self.contacts.data ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.contacts.data?.count ?? 0) Contacts"
                    self.contactsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension ContactsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.contacts?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactsTableViewCell", for: indexPath) as! ContactsTableViewCell
        if let detail = searching ? self.filtered[indexPath.row] : self.contacts?.data?[indexPath.row] {
            cell.ContactLabel.text = "\(detail.username ?? "")"
            
            
        } else {
            cell.ContactLabel.text = "Nil"
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
}

extension ContactsViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = contacts.data?.filter { note in
                return (note.username?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        contactsTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
//        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
//        searchBar.resignFirstResponder()
        contactsTableView.reloadData()
    }
}


