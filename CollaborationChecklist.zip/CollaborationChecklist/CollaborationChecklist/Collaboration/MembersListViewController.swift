//
//  MembersListViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 01/12/23.
//

import UIKit

class MembersListViewController: UIViewController {
    
    @IBOutlet weak var membersTableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    var savedUserId = UserDefaultsManager.shared.getUserName()
    
    var membersDetails: MembersModel!
    var filtered: [UserDetail]!
    var searching : Bool = false
    var collabId = Int()
    var groupName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.membersTableView.delegate = self
        self.membersTableView.dataSource = self
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        collaborationAPI()
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    @IBAction func backAction(_ sender: Any) {
//        dismiss(animated: true)
        navigationController?.popViewController(animated: true)
    }
    
    func collaborationAPI() {
        APIHandler.shared.getAPIValues(type: MembersModel.self, apiUrl: "\(ServiceAPI.GroupMembers)collab_id=\(self.collabId)" , method:"GET") { result in
            switch result {
                
            case .success(let data):
                print(data)
                self.membersDetails = data
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.membersDetails.userDetails?.count ?? 0) Members"
//                    if let details = self.collaboration?.details {
//                        let collabIds = details.compactMap { $0.collabID }
//                        
//                        UserDefaults.standard.set(collabIds, forKey: "CollabIds")
//                    } else {
//                        print("No collaboration details available.")
//                    }
                    self.membersTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension MembersListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // Assuming you have a valid indexPath
        let indexPath = IndexPath(row: 0, section: 0) // You should replace this with the actual indexPath you are working with

        if let userDetails = self.membersDetails?.userDetails,
           indexPath.row < userDetails.count,
           userDetails[indexPath.row].userID == savedUserId {
            return 3
        } else {
            return 2
        }
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if section == 1{
            if searching {
                return self.filtered.count
            } else {
                return self.membersDetails?.userDetails?.count ?? 0
            }
        } else if section == 2 {
            return 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MembersListTableViewCell", for: indexPath) as! MembersListTableViewCell
        
        if indexPath.section == 0 {
            cell.nameLabel.text = "Add Members"
            cell.deleteButton.isHidden = true
            cell.imageIcon.image = UIImage(systemName: "plus.circle.fill")
            cell.imageIcon.tintColor = .black
        } else if indexPath.section == 1 {
            
            // Sort membersDetails?.userDetails based on user type and then alphabetical order
            let sortedUsers = (membersDetails?.userDetails ?? []).sorted { (user1, user2) -> Bool in
                if user1.requestedID == savedUserId {
                    return true
                } else if user2.requestedID == savedUserId {
                    return false
                } else if user1.userID == user1.requestedID {
                    return true
                } else if user2.userID == user2.requestedID {
                    return false
                } else {
                    return user1.username ?? "" < user2.username ?? ""
                }
            }
            
            let detail = searching ? self.filtered[indexPath.row] : sortedUsers[indexPath.row]
            
            if detail.requestedID == savedUserId {
                cell.nameLabel.text = "\(detail.username ?? "") (YOU)"
            } else if detail.userID == detail.requestedID {
                cell.nameLabel.text = "\(detail.username ?? "") (ADMIN)"
            } else {
                cell.nameLabel.text = "\(detail.username ?? "")"
            }
            
            cell.nameLabel.textColor = detail.requestedID == savedUserId ? .black : .black
            cell.deleteButton.isHidden = detail.requestedID == savedUserId
            cell.deleteButton.tag = indexPath.row
            cell.deleteButton.addTarget(self, action: #selector(DeleteMembers), for: .touchUpInside)
            cell.imageIcon.image = UIImage(systemName: "person.fill")
            cell.imageIcon.tintColor = detail.requestedID == savedUserId ? .black : .black
        } else {
            if indexPath.section == 2 {
                    cell.nameLabel.text = "Delete Group"
                    cell.nameLabel.textColor = .red
                    cell.deleteButton.isHidden = true
                    cell.imageIcon.image = UIImage(systemName: "xmark.bin")
                    cell.imageIcon.tintColor = .red
            }
        }
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ContactListViewController") as! ContactListViewController
            vc.modalPresentationStyle = .overCurrentContext
            vc.CollabID = self.collabId
            vc.groupName = self.groupName
            UserDefaults.standard.setValue("Add", forKey: "Add")
            present(vc, animated: true, completion: nil)
        } else if indexPath.section == 2 {
            AlertManager.showDestructiveAlert(title: "DELETE", message: "Are you sure you want to delete this group?", viewController: self, okButtonTitle: "DELETE", cancelButtonTitle: "Cancel", okHandler:  {
                self.DeleteGroup()
            })
           
        }
    }
    
    @objc func DeleteMembers(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let ID = self.membersDetails.userDetails?[rowToRemove].requestedID else {
            return
        }
        
        if let removeIndex = self.membersDetails.userDetails?.firstIndex(where: {$0.requestedID == ID}) {
            
            self.membersDetails.userDetails?.remove(at: removeIndex)
            self.collaborationAPI()
        }
        
        self.membersTableView.reloadData()
        
        let formData = ["collaboration_id" : collabId, "user_id" : ID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteMembers, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.collaborationAPI()
                    self.membersTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    @objc func DeleteGroup() {
        
        let formData = ["Collab_Id" : [collabId]]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteGroupURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
//                    AlertManager.showDestructiveAlert(title: "Delete", message: "Are you sure that you want to delete this group?", viewController: self, okButtonTitle: "DELETE", cancelButtonTitle: "Cancel", cancelHandler:  {
                            for controller in self.navigationController!.viewControllers as Array {
                                if controller.isKind(of: ColloborationTabBar.self) {
                                    self.navigationController!.popToViewController(controller, animated: true)
                                    break
                                }
                            }
//                        self.navigationController?.popViewController(animated: true)
//                    })
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}

extension MembersListViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = membersDetails.userDetails?.filter { task in
                return (task.username?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        membersTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        membersTableView.reloadData()
    }
}

