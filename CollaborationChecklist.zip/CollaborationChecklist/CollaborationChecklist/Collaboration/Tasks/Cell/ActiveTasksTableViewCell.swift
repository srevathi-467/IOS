//
//  ActiveTasksTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class ActiveTasksTableViewCell: UITableViewCell {

    @IBOutlet weak var completebutton: UIView!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var ContentLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
