//
//  VerifiedTasksTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class VerifiedTasksTableViewCell: UITableViewCell {

    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var ContentLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    
//    @IBOutlet weak var VerifiedbyLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
