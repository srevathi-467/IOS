//
//  ActiveTasksViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class ActiveTasksViewController: UIViewController {
    
    @IBOutlet weak var activeTasksTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var countLabel: UILabel!
    
    var activetask : TaskDetailsModel!
    var filtered: [Tasks]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    var completedYes : CompleteYesButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //        completebutton.addAction(for: .tap)
        
        self.activeTasksTableView.delegate = self
        self.activeTasksTableView.dataSource = self
        self.activeTasksTableView.rowHeight = UITableView.automaticDimension
        self.activeTasksTableView.estimatedRowHeight = 100.0 // Set an estimated row height
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
//        AlertManager.showCustomAlert(title: "Leave from tasks", message: "Do you want to leave from tasks?", viewController: self, okButtonTitle: "Leave", cancelButtonTitle: "Cancel", okHandler: {
            self.dismiss(animated: true)
//        })
    }
    override func viewWillAppear(_ animated: Bool) {
        ActivetaskAPI()
    }
    func ActivetaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.ActivetaskURL)userid=\(savedUserId ?? 0)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.activetask = data
                print(self.activetask.tasks ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.activetask.tasks?.count ?? 0) Tasks"
                    self.activeTasksTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension ActiveTasksViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.activetask?.tasks?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ActiveTasksTableViewCell", for: indexPath) as! ActiveTasksTableViewCell
        if let detail = searching ? self.filtered[indexPath.row] : self.activetask?.tasks?[indexPath.row] {
            cell.TitleLabel.text = "\(detail.taskIssued ?? "")"
            cell.ContentLabel.text = "Actived by \(detail.assignedUsername ?? "") from \(detail.groupName ?? "") on \(detail.date ?? "")"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AlertManager.showCustomAlert(title: "Completed", message: "Are you checked the task is complete by \(self.activetask.tasks?[indexPath.row].assignedUsername ?? "") from \(self.activetask.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
            self.YesAPI(at: indexPath)
        },cancelHandler: nil)
    }
    
    func YesAPI(at indexPath: IndexPath) {
        
        guard let taskID = self.activetask?.tasks?[indexPath.row].taskID, let savedUserId = savedUserId else {
                return
            }
    
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.CompleteYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Completed", message: "Task added to completed task", viewController: self, duration: 1.5)
                                
                                // Remove the selected cell from the data source
                                self.activetask?.tasks?.remove(at: indexPath.row)

                                // Reload the table view to reflect the changes
                                self.activeTasksTableView.reloadData()
                            }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension ActiveTasksViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = activetask.tasks?.filter { task in
                return (task.taskIssued?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        activeTasksTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        activeTasksTableView.reloadData()
    }
}

