//
//  MyTasksViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class MyTasksViewController: UIViewController {
    
    @IBOutlet weak var myTasksTableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var taskDetail: TaskDetailsModel!
    var filtered: [Tasks]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.myTasksTableView.delegate = self
        self.myTasksTableView.dataSource = self
        self.myTasksTableView.rowHeight = UITableView.automaticDimension
        self.myTasksTableView.estimatedRowHeight = 100.0 // Set an estimated row height
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.myTasksTableView.reloadData()
        GetTaskDetailsAPI()
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    @IBAction func createAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "CreateTaskViewController") as! CreateTaskViewController
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        //        AlertManager.showCustomAlert(title: "Leave", message: "Do you want to leave from tasks?", viewController: self, okButtonTitle: "Leave", cancelButtonTitle: "Cancel", okHandler: {
        self.dismiss(animated: true)
        //        })
    }
    
    func GetTaskDetailsAPI() {
        
        let ID = UserDefaultsManager.shared.getUserName() ?? 0
        
        guard let savedCollabIds = UserDefaults.standard.array(forKey: "CollabIds") as? [Int] else {
            return
        }
        
        APIHandler().getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.TaskDetailsURL)collab_id=\(savedCollabIds)&UserId=\(ID)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.taskDetail = data
                print(self.taskDetail ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.taskDetail.tasks?.count ?? 0) Tasks"
                    self.myTasksTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
}

extension MyTasksViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.taskDetail?.tasks?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTasksTableViewCell", for: indexPath) as! MyTasksTableViewCell
        
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(DeleteTaskAPI), for: .touchUpInside)
        
        if let detail = searching ? self.filtered[indexPath.row] : self.taskDetail?.tasks?[indexPath.row]{
            cell.taskDetailsLabel.text  = "\(detail.taskIssued ?? "")"
            cell.creatingDetailsLabel.text = "Created by \(detail.assignedUsername ?? "") from \(detail.groupName ?? "") on \(detail.date ?? "")"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AlertManager.showCustomAlert(title: "Completed", message: "Do you want to active the task created by \(self.taskDetail.tasks?[indexPath.row].assignedUsername ?? "") from \(self.taskDetail.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
            self.YesAPI(at: indexPath)
        },cancelHandler: nil)
    }
    
    func YesAPI(at indexPath: IndexPath) {
        
        guard let taskID = self.taskDetail?.tasks?[indexPath.row].taskID, let savedUserId = savedUserId else {
                return
            }
    
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.ActiveYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Active", message: "Task added to active task", viewController: self, duration: 1.5)
                                
                                // Remove the selected cell from the data source
                                self.taskDetail?.tasks?.remove(at: indexPath.row)

                                // Reload the table view to reflect the changes
                                self.myTasksTableView.reloadData()
                            }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    @objc func DeleteTaskAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let TaskID = self.taskDetail.tasks?[rowToRemove].taskID else {
            return
        }
        
        if let removeIndex = self.taskDetail.tasks?.firstIndex(where: {$0.taskID == TaskID}) {
            
            self.taskDetail.tasks?.remove(at: removeIndex)
            self.GetTaskDetailsAPI()
        }
        
        self.myTasksTableView.reloadData()
        
        let formData = ["task_Id" : TaskID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteTaskURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.GetTaskDetailsAPI()
                    self.myTasksTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
}

extension MyTasksViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = taskDetail.tasks?.filter { task in
                return (task.taskIssued?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        myTasksTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        myTasksTableView.reloadData()
    }
}

