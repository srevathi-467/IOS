//
//  VerifiedTasksViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class VerifiedTasksViewController: UIViewController {
    
    @IBOutlet weak var verifiedTasksTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var countLabel: UILabel!
    
    var verifiedtask :TaskDetailsModel!
    var filtered: [Tasks]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.verifiedTasksTableView.delegate = self
        self.verifiedTasksTableView.dataSource = self
        self.verifiedTasksTableView.rowHeight = UITableView.automaticDimension
        self.verifiedTasksTableView.estimatedRowHeight = 100.0 // Set an estimated row height
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    
    @IBAction func backButtonAction(_ sender: Any) {
        //        AlertManager.showCustomAlert(title: "Leave from tasks", message: "Do you want to leave from tasks?", viewController: self, okButtonTitle: "Leave", cancelButtonTitle: "Cancel", okHandler: {
        self.dismiss(animated: true)
        //        })
    }
    override func viewWillAppear(_ animated: Bool) {
        VerifiedTaskAPI()
    }
    
    func VerifiedTaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.VerifiedTaskURL)UserId=\(savedUserId ?? 0)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.verifiedtask = data
                print(self.verifiedtask.tasks ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.verifiedtask.tasks?.count ?? 0) Tasks"
                    self.verifiedTasksTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension VerifiedTasksViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.verifiedtask?.tasks?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VerifiedTasksTableViewCell", for: indexPath) as! VerifiedTasksTableViewCell
        
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(DeleteTaskAPI), for: .touchUpInside)
        
        if let detail = searching ? self.filtered[indexPath.row] : self.verifiedtask?.tasks?[indexPath.row] {
            cell.TitleLabel.text = "\(detail.taskIssued ?? "")"
            cell.ContentLabel.text = "Verified by \(detail.assignedUsername ?? "") from \(detail.groupName ?? "") on \(detail.date ?? "")"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    @objc func DeleteTaskAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let TaskID = self.verifiedtask.tasks?[rowToRemove].taskID else {
            return
        }
        
        if let removeIndex = self.verifiedtask.tasks?.firstIndex(where: {$0.taskID == TaskID}) {
            
            self.verifiedtask.tasks?.remove(at: removeIndex)
            self.VerifiedTaskAPI()
        }
        
        self.verifiedTasksTableView.reloadData()
        
        let formData = ["task_Id" : TaskID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteVerifiedTask, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.VerifiedTaskAPI()
                    self.verifiedTasksTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}

extension VerifiedTasksViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = verifiedtask.tasks?.filter { task in
                return (task.taskIssued?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        verifiedTasksTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        verifiedTasksTableView.reloadData()
    }
}

