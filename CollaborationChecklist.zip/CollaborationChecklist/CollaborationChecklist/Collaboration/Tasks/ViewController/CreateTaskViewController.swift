//
//  CreateTaskViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/11/23.
//

import UIKit

protocol TaskViewControllerDelegate: AnyObject {
    func didDismissViewController()
}

class CreateTaskViewController: UIViewController {
    
//    @IBOutlet weak var collabIdTF: UITextField!
    @IBOutlet weak var contentTF: UITextView!
    
    weak var delegate: TaskViewControllerDelegate?
    
    var collabIds: CollabIDSModel!
    var CollabID = Int()
    let userId = UserDefaultsManager.shared.getUserName()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
//        getCollabIdsAPI()
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(showCollabIdActionSheet))
//        collabIdTF.addGestureRecognizer(tapGesture)
    }
    
//    @objc func showCollabIdActionSheet() {
//        guard let details = self.collabIds?.details else {
//            // Handle the case where collabIds is not available
//            print("Collab IDs not available")
//            return
//        }
//
//        let collabIds = details.map { $0.collabID }
//        let groupName = details.map { $0.groupName }
//
////        guard let collabIdsString = collabIds.joined(separator: ", "),
////              let groupNameString = groupName.joined(separator: ", ") else {
////            // Handle the case where collabIds or groupName is empty
////            print("Collab IDs or Group Name is empty")
////            return
////        }
//
//        let actionSheet = UIAlertController(title: "Select Collab ID", message: nil, preferredStyle: .actionSheet)
//
//        for (index, collabId) in collabIds.enumerated() {
//            let currentGroupName = groupName.indices.contains(index) ? groupName[index] : ""
//            let action = UIAlertAction(title: "\(collabId ?? "") - \(currentGroupName ?? "")", style: .default) { _ in
//                // Set the selected collab ID to collabIdTF
//                self.collabIdTF.text = "\(collabId ?? "")"
//            }
//            actionSheet.addAction(action)
//        }
//
//        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//        actionSheet.addAction(cancelAction)
//
//        // Present the action sheet
//        present(actionSheet, animated: true, completion: nil)
//    }

    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        AddTaskAPI()
        self.dismiss(animated: true)
    }
    
//    func getCollabIdsAPI() {
//        APIHandler.shared.getAPIValues(type: CollabIDSModel.self, apiUrl: "\(ServiceAPI.CollabIdsURL)UserId=\(userId ?? 0)", method: "GET") { result in
//            switch result {
//            case .success(let data):
//                self.collabIds = data
//                print(self.collabIds ?? [])
//                DispatchQueue.main.async {
//                    
//                }
//            case .failure(let error):
//                print(error)
//                print(error.localizedDescription)
//            }
//        }
//    }
    
    func AddTaskAPI() {
        
        let userId = UserDefaultsManager.shared.getUserName() ?? 0
        
        let formData = [
            "UserId" : userId,
            "Collab_Id" : self.CollabID,
            "task_issued" : self.contentTF.text ?? ""
        ] as [String : Any]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.AddTaskURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self, duration: 2.0)
                    self.delegate?.didDismissViewController()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}
