//
//  CompletedTasksViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 29/10/23.
//

import UIKit

class CompletedTasksViewController: UIViewController {
    
    @IBOutlet weak var completedTasksTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var countLabel: UILabel!
    
    var completetask : TaskDetailsModel!
    var filtered: [Tasks]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    var verifiedYes : CompleteYesButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view
        
        self.completedTasksTableView.delegate = self
        self.completedTasksTableView.dataSource = self
        self.completedTasksTableView.rowHeight = UITableView.automaticDimension
        self.completedTasksTableView.estimatedRowHeight = 100.0 // Set an estimated row height
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    
    @IBAction func backButtonAction(_ sender: Any) {
//        AlertManager.showCustomAlert(title: "Leave from tasks", message: "Do you want to leave from tasks?", viewController: self, okButtonTitle: "Leave", cancelButtonTitle: "Cancel", okHandler: {
            self.dismiss(animated: true)
//        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        CompleteTaskAPI()
        }
    func CompleteTaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.CompleteTaskURL)userid=\(savedUserId ?? 0)" , method:"GET") { result in
               switch result {
               case .success(let data):
                   print(data)
                   self.completetask = data
                   print(self.completetask.tasks ?? "")
                   DispatchQueue.main.async {
                       self.countLabel.text = "\(self.completetask.tasks?.count ?? 0) Tasks"
                       self.completedTasksTableView.reloadData()
                   }
               case .failure(let error):
                   print(error)
                   DispatchQueue.main.async{
                       
                   }
                   
               }
           }
       }
    
    
}

extension CompletedTasksViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.completetask?.tasks?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CompletedTasksTableViewCell", for: indexPath) as! CompletedTasksTableViewCell
        if let detail = searching ? self.filtered[indexPath.row] : self.completetask?.tasks?[indexPath.row] {
            cell.TitleLabel.text = "\(detail.taskIssued ?? "")"
                  cell.ContentLabel.text = "Completed by \(detail.assignedUsername ?? "") from \(detail.groupName ?? "") on \(detail.date ?? "")"
              }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AlertManager.showCustomAlert(title: "Verified", message: "Are you verified the task completed by \(self.completetask.tasks?[indexPath.row].assignedUsername ?? "") from \(self.completetask.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
            self.YesAPI(at: indexPath)
        },cancelHandler: nil)
    }
    
    func YesAPI(at indexPath: IndexPath) {
        
        guard let taskID = self.completetask?.tasks?[indexPath.row].taskID, let savedUserId = savedUserId else {
                return
            }
    
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.VerifiedYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Verified", message: "Task added to verified task", viewController: self, duration: 1.5)
                                
                                // Remove the selected cell from the data source
                                self.completetask?.tasks?.remove(at: indexPath.row)
//
//                                // Reload the table view to reflect the changes
                                self.completedTasksTableView.reloadData()
                            }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension CompletedTasksViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = completetask.tasks?.filter { task in
                return (task.taskIssued?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        completedTasksTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        completedTasksTableView.reloadData()
    }
}
