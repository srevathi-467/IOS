//
//  CollaborationViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 09/10/23.
//

import UIKit

class CollaborationViewController: UIViewController {
    
    @IBOutlet weak var collaborationTableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var collaboration : CollabTeamModel!
    var filtered: [Detail]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.collaborationTableView.delegate = self
        self.collaborationTableView.dataSource = self
        
        self.searchBar.isHidden = true
        self.searchBar.delegate = self
        
    }
    
    @IBAction func searchAction(_ sender: Any) {
        searchBar.isHidden = false
    }
    
    @IBAction func notificationButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
//        vc.modalPresentationStyle = .fullScreen
//        self.present(vc, animated: true)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Exit", message: "Do you want to exit from collaboration?", viewController: self, okButtonTitle: "EXIT", cancelButtonTitle: "Cancel", okHandler: {
            self.navigationController?.popViewController(animated: true)
        }, cancelHandler: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        collaborationAPI()
    }
    
    func collaborationAPI() {
        APIHandler.shared.getAPIValues(type: CollabTeamModel.self, apiUrl: "\(ServiceAPI.CollabTeamMembersURL)user_id=\(savedUserId ?? 0)" , method:"GET") { result in
            switch result {
                
            case .success(let data):
                print(data)
                self.collaboration = data
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.collaboration.details?.count ?? 0) Groups"
//                    if let details = self.collaboration?.details {
//                        let collabIds = details.compactMap { $0.collabID }
//                        
//                        UserDefaults.standard.set(collabIds, forKey: "CollabIds")
//                    } else {
//                        print("No collaboration details available.")
//                    }
                    self.collaborationTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}


extension CollaborationViewController: UITableViewDelegate, UITableViewDataSource {
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return self.collaboration?.details?.count ?? 1
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if let detail = self.collaboration?.details?[section] {
//            return detail.members?.count ?? 0
//        }
//        return 0
        if searching {
            return self.filtered.count
        } else {
            return self.collaboration?.details?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CollaborationTableViewCell", for: indexPath) as! CollaborationTableViewCell
        
        if let detail = searching ? self.filtered[indexPath.row] : self.collaboration?.details?[indexPath.row] {
            cell.MembersLabel.text = "\(detail.groupName ?? "")"
        }
//        cell.moreButton.isHidden  = true
//        
//        if let detail = self.collaboration?.details?[indexPath.section] {
//            print("Detail: \(detail)")
//            
//            var memberDetailsArray = detail.members ?? []
//            
//            // Sort the members alphabetically by username
//            memberDetailsArray.sort { (member1, member2) -> Bool in
//                return member1.username?.lowercased() ?? "" < member2.username?.lowercased() ?? ""
//            }
//            
//            if let memberDetails = memberDetailsArray[safe: indexPath.row] {
//                print("Member Details: \(memberDetails)")
//                
//                if memberDetails.requestedid == self.savedUserId {
//                    cell.MembersLabel.text = "\(memberDetails.username ?? "") (You)"
//                    cell.moreButton.isHidden = false
//                    cell.moreButton.tag = indexPath.row
//                    cell.moreButton.addTarget(self, action: #selector(MoreAction), for: .touchUpInside)
//                } else {
//                    cell.MembersLabel.text = "\(memberDetails.username ?? "")"
//                }
//            } else {
//                cell.MembersLabel.text = ""
//            }
//        } else {
//            cell.MembersLabel.text = "No group name"
//        }
        
        return cell
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "GroupDetailsViewController") as! GroupDetailsViewController
//        vc.modalPresentationStyle = .overCurrentContext
        vc.groupName = self.collaboration?.details?[indexPath.row].groupName ?? ""
        vc.CollabId = self.collaboration?.details?[indexPath.row].collabID ?? 0
//        vc.members = self.collaboration?.details?[indexPath.row].members
//        self.present(vc, animated: true)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if let detail = self.collaboration?.details?[section] {
//            return "Group Name: \(detail.groupName ?? "") - ID: \(detail.collabID ?? 0) / \(detail.members?.count ?? 0) Members"
//        }
//        return "No group name"
//    }
    
    @objc func MoreAction(sender: UIButton) {
        
        let selected = sender.tag
        
        let alert = UIAlertController(title: "Select", message: "", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Add Members", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "Remove Members", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Delete Group", style: .destructive, handler: { _ in
            
            guard let collabId = self.collaboration.details?[selected].collabID else {
                return
            }
            
            if let removeIndex = self.collaboration.details?.firstIndex(where: {$0.collabID == collabId}) {
                self.collaboration.details?.remove(at: removeIndex)
                self.collaborationAPI()
            }
            self.collaborationTableView.reloadData()
            
            let formData = ["Collab_Id" : [collabId]]
            
            APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteGroupURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print(response.status ?? "")
                    print(response.message ?? "")
                    DispatchQueue.main.async {
                        self.collaborationAPI()
                    }
                case .failure(let error):
                    print(error)
                    print(error.localizedDescription)
                }
            }
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        self.present(alert, animated: true)
    }
    
}

extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

extension CollaborationViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = collaboration.details?.filter { task in
                return (task.groupName?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        collaborationTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        collaborationTableView.reloadData()
    }
}

