//
//  CollaborationTableViewCell.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 09/10/23.
//

import UIKit

class CollaborationTableViewCell: UITableViewCell {

    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var MembersLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
