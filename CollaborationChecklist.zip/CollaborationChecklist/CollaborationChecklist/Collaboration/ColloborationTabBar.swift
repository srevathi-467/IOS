//
//  ColloborationTabBar.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 27/10/23.
//

import UIKit

class ColloborationTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.delegate = self
    }


}

extension ColloborationTabBar: UITabBarControllerDelegate {
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        if viewController is CreateCollabViewController {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let controller = storyboard.instantiateViewController(withIdentifier: "CreateCollabViewController") as? CreateCollabViewController {
//                controller.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(controller, animated: true)
//                self.present(controller, animated: true, completion: nil)
            }
            return false
        }
        return true
    }
}
