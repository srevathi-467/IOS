//
//  NotificationViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 21/11/23.
//

import UIKit

class NotificationViewController: UIViewController {
    
    @IBOutlet weak var notificationTableView: UITableView!
    
    var NotificationDetails: NotificationModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.notificationTableView.delegate = self
        self.notificationTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        NotificationAPI()
    }
    
    @IBAction func backButton(_ sender: Any) {
//        dismiss(animated: true)
        navigationController?.popViewController(animated: true)
    }
    
    func NotificationAPI() {
        
        let ID = UserDefaultsManager.shared.getUserName() ?? 0
        
//        guard UserDefaults.standard.array(forKey: "CollabIds") is [Int] else {
//           return
//        }
        
        APIHandler().getAPIValues(type: NotificationModel.self, apiUrl: "\(ServiceAPI.GetNotification)requestedId=\(ID)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.NotificationDetails = data
                DispatchQueue.main.async {
                    self.notificationTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}

extension NotificationViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.NotificationDetails?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTableViewCell", for: indexPath) as! NotificationTableViewCell
        
        cell.acceptButton.tag = indexPath.row
        cell.acceptButton.addTarget(self, action: #selector(AcceptAction), for: .touchUpInside)
        
        cell.rejectButton.tag = indexPath.row
        cell.rejectButton.addTarget(self, action: #selector(RejectAction), for: .touchUpInside)
        
        if let detail = self.NotificationDetails?.data?[indexPath.row] {
            cell.infoLabel.text = "\(detail.signupUsername ?? "") invited you to join \(detail.groupName ?? ""). Do you want to join?"
        } else {
            cell.infoLabel.text = "No Notifications"
            cell.acceptButton.isHidden = true
            cell.rejectButton.isHidden = true
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    
    @objc func AcceptAction(sender: UIButton) {
        let selectedRow = sender.tag
        
        let ID = UserDefaultsManager.shared.getUserName() ?? 0
        
        guard let collabID = self.NotificationDetails.data?[selectedRow].collabID else {
            return
        }
        
        if let removeIndex = self.NotificationDetails.data?.firstIndex(where: {$0.collabID == collabID}) {
            self.NotificationDetails.data?.remove(at: removeIndex)
            self.NotificationAPI()
        }
        
        self.notificationTableView.reloadData()
        
        let formData = ["UserId" : ID, "Collab_Id" : collabID] as [String : Any]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.AcceptRequestURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.NotificationAPI()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    @objc func RejectAction(sender: UIButton) {
        let selectedRow = sender.tag
        
        let ID = UserDefaultsManager.shared.getUserName() ?? 0
        
        guard let collabID = self.NotificationDetails.data?[selectedRow].collabID else {
            return
        }
        
        if let removeIndex = self.NotificationDetails.data?.firstIndex(where: {$0.collabID == collabID}) {
            self.NotificationDetails.data?.remove(at: removeIndex)
            self.NotificationAPI()
        }
        
        self.notificationTableView.reloadData()
        
        let formData = ["UserId" : ID, "Collab_Id" : collabID] as [String : Any]
        
        APIHandler.shared.postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.RejectRequestURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.NotificationAPI()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}
