//
//  GroupDetailsViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 01/12/23.
//

import UIKit

class GroupDetailsViewController: UIViewController, TaskViewControllerDelegate {
    
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var taskTableView: UITableView!
    @IBOutlet weak var goupNameLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var taskDetail: TaskDetailsModel!
    var filtered: [Tasks]!
    var searching : Bool = false
    var savedUserId = UserDefaultsManager.shared.getUserName() ?? 0
    
    var groupName = ""
    var CollabId = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.goupNameLabel.text = self.groupName
        
        self.searchBar.delegate = self
        self.searchBar.isHidden = true
        
        self.taskTableView.delegate = self
        self.taskTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            GetTaskDetailsAPI()
        case 1:
            ActivetaskAPI()
        case 2:
            CompleteTaskAPI()
        case 3:
            VerifiedTaskAPI()
        default:
            GetTaskDetailsAPI()
        }
    }
    
    func didDismissViewController() {
        switch segmentController.selectedSegmentIndex {
        case 0:
            GetTaskDetailsAPI()
        case 1:
            ActivetaskAPI()
        case 2:
            CompleteTaskAPI()
        case 3:
            VerifiedTaskAPI()
        default:
            GetTaskDetailsAPI()
        }
    }
    
    @IBAction func membersListAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "MembersListViewController") as! MembersListViewController
//        vc.modalPresentationStyle = .overCurrentContext
        vc.collabId = self.CollabId
        vc.groupName = self.groupName
//        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.searchBar.isHidden = false
    }
    
    @IBAction func createTask(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "CreateTaskViewController") as! CreateTaskViewController
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        viewController.CollabID = self.CollabId
        viewController.delegate = self
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }
    
    @IBAction func backAction(_ sender: Any) {
//        dismiss(animated: true)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func segmentAction(_ sender: Any) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            GetTaskDetailsAPI()
        case 1:
            ActivetaskAPI()
        case 2:
            CompleteTaskAPI()
        case 3:
            VerifiedTaskAPI()
        default:
            GetTaskDetailsAPI()
        }
    }
    
    func GetTaskDetailsAPI() {
        
        APIHandler().getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.TaskDetailsURL)Collab_Id=\(CollabId)&UserId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.taskDetail = data
                print(self.taskDetail ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.taskDetail.tasks?.count ?? 0) Tasks"
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    func ActivetaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.ActivetaskURL)collabid=\(CollabId)&userid=\(savedUserId)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.taskDetail = data
                print(self.taskDetail.tasks ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.taskDetail.tasks?.count ?? 0) Tasks"
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
    func CompleteTaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.CompleteTaskURL)collabid=\(CollabId)&userid=\(savedUserId)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.taskDetail = data
                print(self.taskDetail.tasks ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.taskDetail.tasks?.count ?? 0) Tasks"
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
    func VerifiedTaskAPI() {
        APIHandler.shared.getAPIValues(type: TaskDetailsModel.self, apiUrl: "\(ServiceAPI.VerifiedTaskURL)collabid=\(CollabId)&userid=\(savedUserId)" , method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.taskDetail = data
                print(self.taskDetail.tasks ?? "")
                DispatchQueue.main.async {
                    self.countLabel.text = "\(self.taskDetail.tasks?.count ?? 0) Tasks"
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
}

extension GroupDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.taskDetail?.tasks?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTasksTableViewCell", for: indexPath) as! MyTasksTableViewCell
        
        cell.deleteButton.tag = indexPath.row
        
        switch segmentController.selectedSegmentIndex {
        case 0:
            if let detail = searching ? self.filtered[indexPath.row] : self.taskDetail?.tasks?[indexPath.row]{
                cell.taskDetailsLabel.text  = "\(detail.taskIssued ?? "")"
                cell.creatingDetailsLabel.text = "Created by \(detail.assignedUsername ?? "") on \(detail.date ?? "")"
            }
        case 1:
            if let detail = searching ? self.filtered[indexPath.row] : self.taskDetail?.tasks?[indexPath.row]{
                cell.taskDetailsLabel.text  = "\(detail.taskIssued ?? "")"
                cell.creatingDetailsLabel.text = "Activated by \(detail.assignedUsername ?? "") on \(detail.date ?? "")"
            }
        case 2:
            if let detail = searching ? self.filtered[indexPath.row] : self.taskDetail?.tasks?[indexPath.row]{
                cell.taskDetailsLabel.text  = "\(detail.taskIssued ?? "")"
                cell.creatingDetailsLabel.text = "Completed by \(detail.assignedUsername ?? "") on \(detail.date ?? "")"
            }
        case 3:
            if let detail = searching ? self.filtered[indexPath.row] : self.taskDetail?.tasks?[indexPath.row]{
                cell.taskDetailsLabel.text  = "\(detail.taskIssued ?? "")"
                cell.creatingDetailsLabel.text = "Verified by \(detail.assignedUsername ?? "") on \(detail.date ?? "")"
            }
        default:
            break;
        }
        
        switch segmentController.selectedSegmentIndex {
        case 0, 3:
            cell.deleteButton.isHidden = false
            cell.deleteButton.addTarget(self, action: #selector(DeleteTaskAPI), for: .touchUpInside)
        case 1, 2:
            cell.deleteButton.isHidden = true
            cell.deleteButton.addTarget(self, action: #selector(DeleteTaskAPI), for: .touchUpInside)
        default:
            break
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            AlertManager.showCustomAlert(title: "Active", message: "Do you want to active the task created by \(self.taskDetail.tasks?[indexPath.row].assignedUsername ?? "") from \(self.taskDetail.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
                self.ActiveYesAPI(at: indexPath)
            },cancelHandler: nil)
        case 1:
            AlertManager.showCustomAlert(title: "Completed", message: "Are you checked the task is complete by \(self.taskDetail.tasks?[indexPath.row].assignedUsername ?? "") from \(self.taskDetail.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
                self.CompletedYesAPI(at: indexPath)
            },cancelHandler: nil)
        case 2:
            AlertManager.showCustomAlert(title: "Verified", message: "Are you verified the task completed by \(self.taskDetail.tasks?[indexPath.row].assignedUsername ?? "") from \(self.taskDetail.tasks?[indexPath.row].groupName ?? "")", viewController: self, okButtonTitle: "YES", cancelButtonTitle: "NO", okHandler: {
                self.VerifiedYesAPI(at: indexPath)
            },cancelHandler: nil)
        default:
            break
        }
        
    }
    
    func ActiveYesAPI(at indexPath: IndexPath) {
        
        guard let taskDetail = self.taskDetail,
              let tasks = taskDetail.tasks,
              let taskID = tasks[indexPath.row].taskID else {
            return
        }
        
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.ActiveYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Actived", message: "Task added to actived task", viewController: self, duration: 1.5)
                    
                    // Remove the selected cell from the data source
                    self.taskDetail?.tasks?.remove(at: indexPath.row)
                    
                    // Reload the table view to reflect the changes
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func CompletedYesAPI(at indexPath: IndexPath) {
        
        guard let taskDetail = self.taskDetail,
              let tasks = taskDetail.tasks,
              let taskID = tasks[indexPath.row].taskID else {
            return
        }
        
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.CompleteYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Completed", message: "Task added to completed task", viewController: self, duration: 1.5)
                    
                    // Remove the selected cell from the data source
                    self.taskDetail?.tasks?.remove(at: indexPath.row)
                    
                    // Reload the table view to reflect the changes
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func VerifiedYesAPI(at indexPath: IndexPath) {
        
        guard let taskDetail = self.taskDetail,
              let tasks = taskDetail.tasks,
              let taskID = tasks[indexPath.row].taskID else {
            return
        }
        
        let formData = [
            "task_Id" : taskID,
            "UserId" : savedUserId
        ] as [String : Any]
        
        APIHandler().postAPIValues(type: CompleteYesButton.self, apiUrl: ServiceAPI.VerifiedYesButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "Verified", message: "Task added to verified task", viewController: self, duration: 1.5)
                    
                    // Remove the selected cell from the data source
                    self.taskDetail?.tasks?.remove(at: indexPath.row)
                    //
                    //                                // Reload the table view to reflect the changes
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    @objc func DeleteTaskAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let TaskID = self.taskDetail.tasks?[rowToRemove].taskID else {
            return
        }
        
        if let removeIndex = self.taskDetail.tasks?.firstIndex(where: {$0.taskID == TaskID}) {
            
            self.taskDetail.tasks?.remove(at: removeIndex)
            self.GetTaskDetailsAPI()
        }
        
        self.taskTableView.reloadData()
        
        let formData = ["task_Id" : TaskID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteTaskURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.GetTaskDetailsAPI()
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    @objc func DeleteVerifiedTaskAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let TaskID = self.taskDetail.tasks?[rowToRemove].taskID else {
            return
        }
        
        if let removeIndex = self.taskDetail.tasks?.firstIndex(where: {$0.taskID == TaskID}) {
            
            self.taskDetail.tasks?.remove(at: rowToRemove)
            self.VerifiedTaskAPI()
        }
        
        self.taskTableView.reloadData()
        
        let formData = ["task_Id" : TaskID]
        
        APIHandler().postAPIValues(type: PostStringModel.self, apiUrl: ServiceAPI.DeleteVerifiedTask, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.VerifiedTaskAPI()
                    self.taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
}

extension GroupDetailsViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = taskDetail.tasks?.filter { task in
                return (task.taskIssued?.range(of: searchText, options: .caseInsensitive) != nil)
            }
            
            // Show the cancel button when text begins
            searchBar.setShowsCancelButton(true, animated: true)
        }
        taskTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.isHidden = true
        searchBar.text = "" // Clear the search text
        searching = false
        //        searchBar.setShowsCancelButton(false, animated: true) // Hide the cancel button
        //        searchBar.resignFirstResponder()
        taskTableView.reloadData()
    }
}
