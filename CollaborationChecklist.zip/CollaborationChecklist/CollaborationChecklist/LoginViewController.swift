//
//  LoginViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 03/10/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var UserNameTF: UITextField!
    @IBOutlet weak var PasswordTF: UITextField!
    var login: Login!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        view.endEditing(true)
        
        UserNameTF.text = ""
        PasswordTF.text = ""
    }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
//        navigationController?.pushViewController(vc, animated: true)
//        
    
    if UserNameTF.text == "" && PasswordTF.text == "" {
               let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
               present(alert, animated: true)
           } else {
               GetAPI()
           }
    }

        
        func GetAPI() {
               APIHandler.shared.getAPIValues(type: Login.self, apiUrl: "\(ServiceAPI.LoginURL)username=\(UserNameTF.text ?? "")&password=\(PasswordTF.text ?? "")", method: "GET") { result in
                   switch result {
                   case .success(let data):
                       print(data)
                       self.login = data
                       DispatchQueue.main.async {
                           if self.UserNameTF.text != self.login.data?.first?.username {
                               let alert = UIAlertController(title: "Alert", message: "Incorrect UserID or Password", preferredStyle: UIAlertController.Style.alert)
                               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                               self.present(alert, animated: true)
                           }
                           else {
                               UserDefaultsManager.shared.saveUserId(self.login.data?.first?.UserId ?? 0)
//                                   UserDefaultsManager.shared.saveUserId(self.UserNameTF.text ?? "")
                                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                   let vc = storyboard.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
                                   self.navigationController?.pushViewController(vc, animated: true)
                               
                       }
                       }
                   case .failure(let error):
                       print(error)
                   }
               }
           }

    
        
}
