//
//  Alert.swift
//  CommuniHelp
//
//  Created by SAIL on 20/10/23.
//

import Foundation
import UIKit

class AlertManager {
    
    static func showAutoDismissAlert(title: String, message: String, viewController: UIViewController, navigationController: UINavigationController, duration: TimeInterval = 2.0) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        viewController.present(alertController, animated: true, completion: nil)
        
        // Create a timer to automatically dismiss the alert after the specified duration
        let timer = Timer(timeInterval: duration, repeats: false) { _ in
            alertController.dismiss(animated: true, completion: {
                navigationController.popViewController(animated: true)
            })
        }
        RunLoop.main.add(timer, forMode: .common)
    }
    
    static func showAutoDismissAlert(title: String, message: String, viewController: UIViewController, duration: TimeInterval = 2.0) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        viewController.present(alertController, animated: true, completion: nil)
        
        // Create a timer to automatically dismiss the alert after the specified duration
        let timer = Timer(timeInterval: duration, repeats: false) { _ in
            alertController.dismiss(animated: true, completion: {
               
            })
        }
        RunLoop.main.add(timer, forMode: .common)
    }
    
    static func showAlert(title: String, message: String, viewController: UIViewController, completionHandler: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler?()
        }
        alertController.addAction(okAction)
        
        viewController.present(alertController, animated: true, completion: nil)
    }
    
    static func showCustomAlert(title: String, message: String, viewController: UIViewController, okButtonTitle: String, cancelButtonTitle: String, okHandler: (() -> Void)? = nil, cancelHandler: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: okButtonTitle, style: .default) { _ in
            okHandler?()
        }
        alertController.addAction(okAction)
        
        let cancelAction = UIAlertAction(title: cancelButtonTitle, style: .cancel) { _ in
            cancelHandler?()
        }
        alertController.addAction(cancelAction)
        
        viewController.present(alertController, animated: true, completion: nil)
    }
    
    static func showDestructiveAlert(title: String, message: String, viewController: UIViewController, okButtonTitle: String, cancelButtonTitle: String, okHandler: (() -> Void)? = nil, cancelHandler: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: okButtonTitle, style: .destructive) { _ in
            okHandler?()
        }
        alertController.addAction(okAction)
        
        let cancelAction = UIAlertAction(title: cancelButtonTitle, style: .cancel) { _ in
            cancelHandler?()
        }
        alertController.addAction(cancelAction)
        
        viewController.present(alertController, animated: true, completion: nil)
    }
}
