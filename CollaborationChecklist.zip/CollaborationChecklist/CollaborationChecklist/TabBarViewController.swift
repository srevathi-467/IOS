//
//  TabBarViewController.swift
//  CollaborationChecklist
//
//  Created by Haris Madhavan on 03/10/23.
//

import UIKit

class TabBarViewController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.delegate = self
    }
}
    
extension TabBarViewController: UITabBarControllerDelegate {
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        if viewController is ColloborationTabBar {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let controller = storyboard.instantiateViewController(withIdentifier: "ColloborationTabBar") as? ColloborationTabBar {
//                controller.modalPresentationStyle = .fullScreen
//                self.present(controller, animated: true, completion: nil)
                self.navigationController?.pushViewController(controller, animated: true)
            }
            return false
        }
        return true
    }
    
}
