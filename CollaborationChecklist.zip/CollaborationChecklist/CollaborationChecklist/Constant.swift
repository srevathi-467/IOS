//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

struct ServiceAPI {
    static let baseURL = "http://172.18.78.249//"
    static let todogetURL = baseURL+"IOS/todoget.php?" //User_id=2
    static let LoginURL = baseURL+"IOS/login.php?" //username=revathi&password=revathi
    static let signupURL = baseURL+"IOS/signup.php"
    static let CollaborationURL = baseURL+"IOS/collabget.php?" //notebook_id=1&person1=7337300596
    static let NotesURL = baseURL+"IOS/notesget.php?" //?User_id=1
    static let ContactsURL = baseURL+"IOS/contact.php"
    static let ActivetaskURL = baseURL+"IOS/display_active.php?"
    static let CompleteTaskURL = baseURL+"IOS/display_completed.php?" //User_id=2
    static let VerifiedTaskURL = baseURL+"IOS/display_verified.php?" //User_id=3
    static let collaborationURL = baseURL+"IOS/collabMembers.php?" //user_id=3
    static let ActiveYesButtonURL = baseURL+"IOS/yes_for_active.php?"
    static let CompleteYesButtonURL = baseURL+"IOS/yes_for_complete.php?"
    static let VerifiedYesButtonURL = baseURL+"IOS/yes_for_verified.php?"
    static let AddNotesURL = baseURL+"IOS/notesadd_Post.php?"
    static let CreateTeamURL = baseURL+"IOS/CollabrequestR.php?"
    static let CollabTeamMembersURL = baseURL+"IOS/group.php?" //user_id=2
    static let TaskDetailsURL = baseURL+"IOS/task_get.php?"
    static let DeleteNotesURL = baseURL+"IOS/delete_notes_post.php"
    static let GetNotification = baseURL+"IOS/notification.php?"
    static let AddTodoListURL = baseURL+"IOS/TodoAddPost.php?"
    static let UpdateTodoURL = baseURL+"IOS/update_todo.php?"
    static let AcceptRequestURL = baseURL+"IOS/accept_request.php?"
    static let RejectRequestURL = baseURL+"IOS/rejected_request.php?"
    static let AddTaskURL = baseURL+"IOS/task.php?"
    static let DeleteVerifiedTask = baseURL+"IOS/delete_verified_onerow.php?"
    static let DeleteTaskURL = baseURL+"IOS/task_delete_post.php?"
    static let CollabIdsURL = baseURL+"IOS/collab_ids.php?"
    static let DeleteGroupURL = baseURL+"IOS/Delete_Group.php?"
    static let GroupMembers = baseURL+"IOS/groupmembers.php?"
    static let DeleteMembers = baseURL+"IOS/delete_onerow.php?"
    static let DeleteTodoURL = baseURL+"IOS/delete_todo_post.php?"
    static let AddMembersURL = baseURL+"IOS/insertmembers.php?"
    static let LogoutURL = baseURL+"IOS/logout.php?"
}
